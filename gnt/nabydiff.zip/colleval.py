#! /usr/bin/python
#
# read an inline collation and classify each line-variant.
#
import sys

def isplacer( s):
    "predicate for string 'nut' with some chars replaced by . or -"
    return len( s) == 3 and s[ 0] in "n.-" and s[ 1] in "uc.-" and s[ 2] in "t.-"

evalstrings = ["cpx", "del", "ins", "kde", "mnu", "nil", "spc", "spl", "sub", "tra"]

def ismarker( s):
    return len( s) == 14 and s[ 3] == "-" and s[ 8] == "-" and s[11] == "-"

def movenupair( s, t):
    if s[-1] == "N":
        tt = s
        s = t
        t = tt
    return (s+"N" == t) and (s[ -1:] == "E" or s[ -2:] == "SI" or s[ -2:] == "CI"  or s == "ESTI")

def lepspair( s, t):
    # pairs like "LHMFQH" and "LHFQH"
    if len( s) == len( t) + 1:
        tt = s
        s = t
        t = tt
    elif len( s) != len( t) - 1:
        return 0
    # len( s) == len( t) - 1
    i = t.find( "LHM")
    if i < 0 or i > len( t) - 5: return 0
    if s != t[: i]+"LH"+t[ i+3:]: return 0
    return t[ i+3:][: 1] in ("P", "F", "Y")

conpairs=[("KAI EGW","KAGW"),
          ("KAI EKEI", "KAKEI"),
          ("KAI EKEIQEN", "KAKEIQEN"),
          ("KAI EAN", "KAN"),
          ("KAI EME", "KAME"),
          ("KAI EMOI", "KAMOI"),
          ("KAI EKEINOS", "KAKEINOS"),
          ("KAI EKEINOUS", "KAKEINOUS"),
          ("KAI EKEINOI", "KAKEINOI"),
          ("EIKOSI TESSARES", "KD")]

sppairs=[("ALLA","ALL"),
        ("ABADDWN", "ABBADWN"),
        ("AKELDAMAX", "AKELDAMA"),
        ("ANTIKRU","ANTIKRUS"),
        ("APORIYANTAS","APORRIYANTAS"),
        ("AXRI","AXRIS"),
        ("BOOS", "BOOZ"),
        ("DWDEKA","IB"),
        ("EKXUNNOMENON","EKXUNOMENON"),
        ("UPEREKXUNNOMENON","UPEREKXUNOMENON"),
        ("EUQUS","EUQEWS"),
        ("EAN","AN"),
        ("ENEKA","ENEKEN"),
        ("EPARXIA","EPARXEIA"),
        ("EPARXIAS","EPARXEIAS"),
        ("ERAUNA", "EREUNA"),
        ("ERAUNATE", "EREUNATE"),
        ("ERAUNHSON", "EREUNHSON"),
        ("ERAUNWN", "EREUNWN"),
        ("ERAUNWNTES", "EREUNWNTES"),
        ("HSSON", "HTTON"),
        ("IAIROS", "IAEIROS"),
        ("ELIAKIM", "ELIAKEIM"),
        ("ISSAXAR", "ISAXAR"),
        ("IWRIM", "IWREIM"),
        ("KAFARNAOUM", "KAPERNAOUM"),
        ("KOLWNIA","KOLWNEIA"),
        ("KREISSON", "KREITTON"),
        ("LAODIKEWN", "LAODIKAIWN"),
        ("MAQQAION", "MATQAION"),
        ("MAQQAIOS", "MATQAIOS"),
        ("MAQQAT", "MATQAT"),
        ("MAQQIAN", "MATQIAN"),
        ("MESSIAN", "MESIAN"),
        ("MESSIAS", "MESIAS"),
        ("MWUSEA","MWSEA"),
        ("MWUSEI","MWSEI"),
        ("MWUSEWS","MWSEWS"),
        ("MWUSH","MWSH"),
        ("MWUSHN","MWSHN"),
        ("MWUSHS","MWSHS"),
        ("NEFQALIM", "NEFQALEIM"),
        ("OUTW","OUTWS"),
        ("PAN", "APAN"),
        ("PANTA", "APANTA"),
        ("PANTAS", "APANTAS"),
        ("PANTES", "APANTES"),
        ("PASAN", "APASAN"),
        ("PAS", "APAS"),
        ("PERIRHCANTES", "PERIRRHCANTES"),
        ("PANOIKEI", "PANOIKI"),
        ("PASIN", "APASIN"),
        ("PRAUS", "PRAOS"),
        ("PRAUTHS", "PRAOTHS"),
        ("PRAUTHTA", "PRAOTHTA"),
        ("PRAUTHTI", "PRAOTHTI"),
        ("PRAUTHTOS", "PRAOTHTOS"),
        ("SALEIM", "SALHM"),
        ("SAMARITAI", "SAMAREITAI"),
        ("SAMARITAIS", "SAMAREITAIS"),
        ("SAMARITHS", "SAMAREITHS"),
        ("SAMARITIDOS", "SAMAREITIDOS"),
        ("SAMARITIS", "SAMAREITIS"),
        ("SAMARITWN", "SAMAREITWN"),
        ("SAPFIRH", "SAPFEIRH"),
        ("SAPFIROS", "SAPFEIROS"),
        ("SUNEXUNNEN", "SUNEXUNEN"),
        ("SUROFOINIKISSA","SURAFOINIKISSA"),
        ("TETRAARXHS","TETRARXHS"),
        ("TETRAARXOU","TETRARXOU"),
        ("TETRAARXOUNTOS","TETRARXOUNTOS"),
        ("TESSERAKONTA","TESSARAKONTA"),
        ("TESSERAKONTAETH","TESSARAKONTAETH"),
        ("TESSERAKONTAETHS","TESSARAKONTAETHS"),
        ("EIPON","EIPAN"),
        ("HLQON","HLQAN"),
        ("APHLQON","APHLQAN"),
        ("EPHLQON","EPHLQAN"),
        ("ECHLQON","ECHLQAN"),
        ("PROSHLQON","PROSHLQAN"),
        ("DE","D"),
        ("DIA","DI"),
        ("APO","AP"),
        ("APO","AF"),
        ("UPO","UP"),
        ("UPO","UF"),
        ("EPI","EP"),
        ("EPI","EF"),
        ("KATA","KAT"),
        ("KATA","KAQ"),
        ("META","MET"),
        ("META","MEQ")]
sppairmap={}
conpairmap={}
for (p,q) in sppairs:
    sppairmap[ (p,q)] = 1
    sppairmap[ (q,p)] = 1
for (p,q) in conpairs:
    conpairmap[ (p,q)] = 1
    conpairmap[ (q,p)] = 1

def spellpair( s, t):
    if lepspair( s, t): return 1
    return sppairmap.has_key( (s, t))

def contractpair(s,t):
    return conpairmap.has_key( (s, t))

argv = sys.argv[ 1:]
if len( argv) > 0 and argv[ 0][ 0] == "-" and len( argv[ 0]) == 3:
    pastflag = argv[ 0][ 1]
    futflag = argv[ 0][ 2]
    argv = argv[ 1:]
else:
    pastflag = "-"
    futflag = "+"

if len( argv) == 1:
    coll = open( argv[ 0], "r")
else:
    coll = sys.stdin

for li in coll:
    wds = li.split()
    if isplacer( wds[ 0]):
        placer = wds[ 0]
        wds = wds[ 1:]
    else:
        placer = "..."
    if wds[ 0] in evalstrings:
        wds = wds[ 1:]
    if not ismarker( wds[ 0]):
        raise ValueError, "missing verse marker in "+li
    restline = " ".join( wds)
    wds = wds[ 1:]
    
    while len( wds) > 1 and wds[ 0][ 0] not in [pastflag, futflag]:
        wds = wds[ 1:]
    while len( wds) > 1 and wds[ -1][ 0] not in [pastflag, futflag]:
        wds = wds[: -1]
    nnew = nold = nboth = 0
    old=[]
    new=[]
    for w in wds:
        if w[ 0] == futflag:
            new.append( w[ 1:])
            nnew = nnew + 1
        elif w[ 0] == pastflag:
            old.append( w[ 1:])
            nold = nold + 1
        else:
            old.append( w)
            new.append( w)
            nboth = nboth + 1
    if nnew == 0 and nold == 0:
        kind = "nil"
    elif nnew == 0:
        kind = "del"
    elif nold == 0:
        kind = "ins"
    elif "".join( old) == "".join( new):
        kind = "spc"
    else:
        oldw = old[:]
        neww = new[:]
        oldw.sort()
        neww.sort()
        if " ".join( oldw) == " ".join( neww):
            kind = "tra"
        elif nold == 1 and nnew == 1 and nboth == 0:
            if movenupair( old[ 0], new[ 0]):
                kind = "mnu"
            elif spellpair( old[ 0], new[ 0]):
                kind = "spl"
            else:
                kind = "sub"
        elif nold + nboth + nboth + nnew == 3 and contractpair( " ".join( old), " ".join( new)):
            kind = "spl"
        elif nold == 1 and nnew == 1 and nboth == 1:
            if old[ 0] == "KAI" and new[ 1] == "DE" and old[ 1] == new[ 0]:
                kind = "kde"
            elif new[ 0] == "KAI" and old[ 1] == "DE" and new[ 1] == old[ 0]:
                kind = "kde"
            else:
                kind = "cpx"
        else:
            kind = "cpx"
    sys.stdout.write( placer + " " + kind + " " + restline + " \n")
