These files collate the NA26/27 GNT text against the 2000 Robinson-Pierpont
Byzantine GNT text with some analytical commentary.
The collation has mostly been factored so that neighboring units of variation
are separate if they seem to be independent, combined if dependent.

readme.txt      this file
N-B-COLL	collation with NA words marked "-", BY words marked "+"
N-B-VERSES	differences in verse numbering in the NA and BY texts
coll2pat.py	python script to create a patch from the collation
collappl.py	python script to combine a base text with a collation
colleval.py	python script to autoclassify many of the collation variants
multivar.py     python script to select verses with more than one variant
split.el        emacs functions to help edit
Makefile        to update dependent files

If NA is a copy of NA27, one word per line, including bracketed words,
but brackets eliminated, with only the long ending of Mark,
and BY is the R-P Byzantine text in similar format, then

	python collappl.py NA N-B-COLL BY1
	python collappl.py BY1 N-B-VERSES BY2
	diff BY2 BY

should report no differences. This is done by "make N-B-COLL.errs"
The Makefile will create NA and BY from the verse-per-line files I distribute.

N-B-COLL now also has prefixed on each line an indication of the
variant's significance and a classification of type of change involved.

The significance is summarized by three characters, in the order "nut",
where "n" indicates that the variant is documented in the NA27 apparatus,
"u" indicates the variant is documented in the UBS3 apparatus,
and "t" indicates the variant should be visible in an English translation.
Each character may be replaced by "-" to indicate the opposite,
i.e. not documented or not translatable, or by "." if not checked yet.
E.g. "n-." means in NA27, not in UBS3, no comment whether it is translatable.

The classes of variants identified are (with counts of occurrences):

  49	spc	change of word division spacing
  45	mnu	ins/del movable nu
 542	spl	other minor spelling difference
 596	del	deletion
1730	ins	insertion
2299	sub	one word substitution
  55    kde     interchange of KAI foo and foo DE
 753	tra	transposition of words
 824	cpx	more complex variation, i.e. miscellaneous
6893            total

Report errors and potential improvements to me.
Vincent Broman <vpbroman@mstar2.net>
