#! /usr/bin/python
#
# print out verses with more than one variant
#
import sys

vars={}
for li in sys.stdin:
    vs = li[ 4: 18]
    if vars.has_key( vs):
        vars[ vs].append( li)
    else:
        vars[ vs] = [li]
vss=vars.keys()
vss.sort()
for vs in vss:
    if len( vars[ vs]) > 1:
        print "".join( vars[ vs])
