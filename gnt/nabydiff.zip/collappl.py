#! /usr/bin/python
#
# read an inline collation and apply it as a patch
# usage: python collappl.py [basetext [collation [outputtext]]]
#
import sys

def isplacer( s):
    "predicate for string 'nut' with some chars replaced by . or -"
    return len( s) == 3 and s[ 0] in "n.-" and s[ 1] in "u.-" and s[ 2] in "t.-"

evalstrings = ["cpx", "del", "ins", "kde", "mnu", "spc", "spl", "sub", "tra"]

def ismarker( s):
    return len( s) == 14 and s[ 3] == "-" and s[ 8] == "-" and s[11] == "-"

badcolle="badcoll"
def checkf( newadv, targ, advance):
    if newadv < 0:
        sys.stderr.write( "@@@@ could not find" + `targ` + ", advance=" + `advance` + "\n")
        raise badcolle

argv = sys.argv[ 1:]
if len( argv) > 0 and argv[ 0][ 0] == "-" and len( argv[ 0]) == 3:
    pastflag = argv[ 0][ 1]
    futflag = argv[ 0][ 2]
    argv = argv[ 1:]
else:
    pastflag = "-"
    futflag = "+"

if len( argv) >= 1:
    textf = argv[ 0]
else:
    textf = "NA"
text = open( textf, "rt").read()
if len( argv) >= 2:
    coll = open( argv[ 1], "rt")
else:
    coll = sys.stdin
if len( argv) == 3:
    outp = open( argv[ 2], "wt")
else:
    outp = sys.stdout

advance = 0
lastvs = ""
for li in coll:
    wds = li.split()
    if len( wds) > 1 and isplacer( wds[ 0]):
        wds = wds[ 1:]
    if len( wds) > 1 and wds[ 0] in evalstrings:
        wds = wds[ 1:]
    if ismarker( wds[ 0]):
        vs = wds[ 0]
        wds = wds[ 1:]
    else:
        vs = lastvs
    if vs != lastvs:
        newadv = text.find( vs, advance)
        checkf( newadv, vs, advance)
        newadv = newadv + len( vs)
        outp.write( text[ advance: newadv])
        advance = newadv
        lastvs = vs
    old = []
    new = []
    for w in wds:
        if w[ 0] == futflag:
            new.append( w[ 1:])
        elif w[ 0] == pastflag:
            old.append( w[ 1:])
        else:
            old.append( w)
            new.append( w)
            if ismarker( w):
                lastvs = vs = w
    if len(old) == 0:
        old = ""
    else:
        old = "\n" + "\n".join( old)
    if len( new) == 0:
        new = ""
    else:
        new = "\n" + "\n".join( new)
    newadv = text.find( old, advance)
    checkf( newadv, old, advance)
    outp.write( text[ advance: newadv])
    outp.write( new)
    advance = newadv + len( old)
outp.write( text[ advance:])
