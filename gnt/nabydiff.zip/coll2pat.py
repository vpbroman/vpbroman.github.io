#! /usr/bin/python
#
# read an inline collation and output an equivalent unified patch.
#
import sys

def genpat( wdlist, wdno):
    global offset, advance
    plus = minus = both = 0
    prefixed=[]
    for w in wdlist:
        if w[0] == "+":
            plus = plus + 1
            add = w
        elif w[0] == "-":
            minus = minus + 1
            add = w
        else:
            both = both + 1
            add = " "+w
        prefixed.append( add)
    print "@@ -" + `wdno` + "," + `both+minus` + " +" + `wdno+offset` + "," + `both+plus` + " @@"
    print "\n".join( prefixed)
    offset = offset + (plus - minus)
    advance = advance + both + minus

def getvslines( fn):
    vstoline = {}
    for v in open( fn, "rt"):
        p = ":".split( v[: -1])
        vstoline[ p[ 1]] = int( p[ 0])
    return vstoline

vs_to_line = getvslines( "naverses")
offset = 0
advance = 0

lastvs = ""
for li in sys.stdin:
    wds = li.split()
    vs = wds[ 0]
    wno = vs_to_line[ vs]
    if vs != lastvs:
        genpat( ["-"+vs, "+"+vs], wno)
        advance = 0
    genpat( wds[ 1:], wno+advance)
    lastvs = vs
