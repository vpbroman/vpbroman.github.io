#! /usr/local/bin/python
#
# This code reads the pyuncont.txt file and fills in the implicit repeated fields.
#
import sys, string

ms = bk = ""
for li in sys.stdin.readlines():
    wds = string.split( li, "\t")
    if wds[0]:  ms = wds[0]
    else:       wds[0] = ms
    if wds[1]:  bk = wds[1]
    else:       wds[1] = bk
    print string.join(wds, "\t"),
